import subprocess
import sys

def show_menu():
    print("Welcome to the Minecraft Clone Game")
    print("1. Start Game")
    print("2. Exit")

def run_java_game():
    try:
        # Running the Java game using subprocess
        subprocess.run(["java", "MinecraftClone"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error while running Java game: {e}")
        sys.exit(1)

def main():
    while True:
        show_menu()
        choice = input("Enter your choice: ")

        if choice == "1":
            print("Starting the game...")
            run_java_game()
        elif choice == "2":
            print("Exiting the game.")
            sys.exit(0)
        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()