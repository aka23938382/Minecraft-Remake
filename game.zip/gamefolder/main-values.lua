-- game_values.lua: This file handles game values such as score, inventory, and world state

-- Global variables
local score = 0
local inventory = {}
local placed_blocks = 0

-- Initialize inventory with some items
function initializeInventory()
    inventory["stone"] = 0
    inventory["wood"] = 0
    inventory["dirt"] = 0
end

-- Function to add items to the inventory
function addItemToInventory(item, count)
    if inventory[item] then
        inventory[item] = inventory[item] + count
    else
        inventory[item] = count
    end
end

-- Function to update score
function updateScore(points)
    score = score + points
end

-- Function to place a block and update the world state
function placeBlockAndUpdate(x, y, block)
    -- Place the block (this assumes `placeBlock` exists in `game.lua`)
    placeBlock(x, y, block)
    
    -- Update inventory (example: place "stone" block)
    if block == '#' then
        addItemToInventory("stone", 1)
        updateScore(10)  -- Add 10 points for placing a block
    end
    
    -- Update the number of placed blocks
    placed_blocks = placed_blocks + 1
end

-- Get the current score
function getScore()
    return score
end

-- Get the current inventory
function getInventory()
    return inventory
end

-- Get the total number of blocks placed
function getPlacedBlocks()
    return placed_blocks
end

-- Initialize the game values
initializeInventory()

return {
    addItemToInventory = addItemToInventory,
    updateScore = updateScore,
    placeBlockAndUpdate = placeBlockAndUpdate,
    getScore = getScore,
    getInventory = getInventory,
    getPlacedBlocks = getPlacedBlocks
}