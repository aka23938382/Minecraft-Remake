public class MinecraftClone {
    // The size of the world grid
    static final int WIDTH = 10;
    static final int HEIGHT = 5;
    
    // World grid (2D array of blocks)
    static char[][] world = new char[HEIGHT][WIDTH];

    public static void main(String[] args) {
        initializeWorld();
        printWorld();
        
        // Simulate placing a block at (3, 2)
        placeBlock(3, 2, '#');
        printWorld();
    }
    
    // Initialize the world with empty space
    public static void initializeWorld() {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                world[i][j] = '.'; // '.' represents empty space
            }
        }
    }
    
    // Place a block in the world
    public static void placeBlock(int x, int y, char block) {
        if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
            world[y][x] = block;
        }
    }

    // Print the world grid to the console
    public static void printWorld() {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                System.out.print(world[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
}