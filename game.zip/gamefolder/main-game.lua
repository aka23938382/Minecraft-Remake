-- Load the game values from the other Lua script (game_values.lua)
local gameValues = require "main-values"

-- Constants for the world size
local WIDTH = 10
local HEIGHT = 5
local block_size = 40

-- Game world (2D array for blocks)
local world = {}

-- Function to initialize the world with empty blocks
function initializeWorld()
    for y = 1, HEIGHT do
        world[y] = {}
        for x = 1, WIDTH do
            world[y][x] = '.'  -- '.' is empty space
        end
    end
end

-- Function to place a block at a given position
function placeBlock(x, y, block)
    if x >= 1 and x <= WIDTH and y >= 1 and y <= HEIGHT then
        world[y][x] = block
    end
end

-- Love2D callback: load (called once when the game starts)
function love.load()
    initializeWorld()
end

-- Love2D callback: update (called every frame)
function love.update(dt)
    -- You could add player movement or other features here
end

-- Love2D callback: draw (called every frame to render the screen)
function love.draw()
    -- Draw the grid of blocks
    for y = 1, HEIGHT do
        for x = 1, WIDTH do
            local block = world[y][x]
            if block == '.' then
                love.graphics.setColor(0.8, 0.8, 0.8)  -- Light gray for empty space
            elseif block == '#' then
                love.graphics.setColor(0.2, 0.8, 0.2)  -- Green for blocks
            end
            love.graphics.rectangle("fill", (x-1) * block_size, (y-1) * block_size, block_size, block_size)
        end
    end
    
    -- Draw the UI (score, inventory, and placed blocks)
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Score: " .. gameValues.getScore(), 10, HEIGHT * block_size + 10)
    love.graphics.print("Blocks Placed: " .. gameValues.getPlacedBlocks(), 10, HEIGHT * block_size + 30)
    love.graphics.print("Inventory (Stone): " .. gameValues.getInventory()["stone"], 10, HEIGHT * block_size + 50)
end

-- Love2D callback: keypressed (handle user input)
function love.keypressed(key)
    if key == 'p' then
        -- Simulate placing a block at position (3, 2)
        gameValues.placeBlockAndUpdate(3, 2, '#')
    end
end